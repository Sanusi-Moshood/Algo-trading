
import HomePage from './components/HomePage';
import './index.css'

function App() {
  return (
    <>
      <HomePage/>
    </>
  );
}

export default App;
