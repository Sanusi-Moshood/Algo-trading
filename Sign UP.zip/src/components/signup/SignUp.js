import {useState} from 'react' 
import './signup.css'
import signImg from '../../images/logbg.png'
import { HiOutlineMail } from 'react-icons/hi'
import { FaYoutube } from 'react-icons/fa'
import { SiTelegram } from 'react-icons/si'


export default function SignUp() {
    const [signUp, setSignUp] = useState(false)
    const [LoginData, setLoginData] = useState(
        {email: "", password: "", ConfirmPassword: ""}
      )

      const handleChange =(event) => {
        setLoginData(prevLoginData => {
            return {
                ...prevLoginData,
                [event.target.name]: event.target.value
            }
        })
      }

    const toggleForm = (e) => {
        e.preventDefault();

        setSignUp(prev => !prev)
        // console.log(signUp)
    }
    const handleSubmit = (e) => {
        e.preventDefault();
    }
  return (
    <section>
        <div className="container">
            <div className="user">
                <div className="sign_img">
                    <img src={signImg} alt="" />
                </div>
                <div className="form_box">
                    <div className="form_wrapper">
                        <div className="auth_btn">
                            <button onClick={toggleForm} className={`toggle_btn ${signUp ? 'btn-light' : 'btn-dark' }`}>Sign up</button>
                            <button onClick={toggleForm} className={`toggle_btn ${!signUp ? 'btn-light' : 'btn-dark' }`}>Login</button>
                        </div>
                        <h1>{!signUp ? 'Create Account' : 'Login Account'}</h1>

                    {/*------------------ Toggle Sign Up Or Login Form-------------------- */}
                        {signUp ?
                        <form action="" onSubmit={handleSubmit}>
                        <input 
                            type="text"
                            placeholder='E-mail'
                            onChange={handleChange}
                            name="email"
                            value={LoginData.email}
                        />
                        <input 
                            type="password"
                            placeholder='Password'
                            onChange={handleChange}
                            name="password"
                            value={LoginData.password}
                        />
                        <p className='log_in'>
                            Don't have Account? 
                            <a href="#" onClick={toggleForm}>Sign up</a>
                        </p>
                        <input type="submit" value="Login" />
                        </form>
                         :
                         <form action="" onSubmit={handleSubmit}>
                         <input 
                             type="text"
                             placeholder='E-mail'
                             onChange={handleChange}
                             name="email"
                             value={LoginData.email}
                         />
                         <input 
                             type="password"
                             placeholder='Password'
                             onChange={handleChange}
                             name="password"
                             value={LoginData.password}
                         />
                         <input 
                             type="password"
                             placeholder='Confirm password'
                             onChange={handleChange}
                             name="ConfirmPassword"
                             value={LoginData.ConfirmPassword}
                         />
                         <p className='log_in'>
                             Already have an account?
                             <a href="#" onClick={toggleForm}>sign in</a>
                         </p>
                         <input type="submit" value="Sign Up" />
                     </form>
                         
                         }


                        {/*------------------ Contact Links-------------------- */}
                        <div className="sign_link">
                            <div>
                                <HiOutlineMail />
                                <a href="#">
                                    Contact us
                                    <span></span>
                                </a>
                            </div>
                            <div>
                                <FaYoutube />
                                <a href="#">
                                    Subscribe us
                                    <span></span>
                                </a>
                            </div>
                            <div>
                                <SiTelegram />
                                <a href="#">
                                    Join us
                                    <span></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  )
}
