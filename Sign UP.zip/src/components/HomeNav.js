import React from 'react'

const HomeNav = () => {
  return (
    <nav>
      <div className="nav-container">
        
      </div>
    </nav>
  )
}

export default HomeNav
