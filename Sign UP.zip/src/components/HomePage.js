import React from 'react'
import HomeNav from './HomeNav'
import LoginSignup from './LoginSignup'
import SignUp from './signup/SignUp'


const HomePage = () => {
  return (
    <>
      <div>
        <SignUp />
      </div>
      {/* <LoginSignup /> */}
    </>
  )
}

export default HomePage
