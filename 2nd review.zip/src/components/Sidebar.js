import React from 'react'

const Sidebar = () => {
  return (
    <div>
      Sidebar
    </div>
  )
}

export default Sidebar
